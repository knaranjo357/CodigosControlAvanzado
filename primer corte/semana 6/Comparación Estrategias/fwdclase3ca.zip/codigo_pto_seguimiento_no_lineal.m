clc
clear
close all
syms x1 x2 x3 u1 u2 u3 a b c
f1 = -a*x1^2+x2+u2*u3;
f2 = -x2+b*x3-u1*u3;
f3 = -c*x3^2+exp(-u1);
F = [f1; f2; f3]
X = [x1; x2; x3]
U = [u1; u2; u3]
A = jacobian(F,X)
B = jacobian(F,U)
u10 = 1
u20 = 2
u30 = 3
x30 = sqrt((exp(-u10))/c)
x20 = b*x30 - u10*u30
x10 = sqrt((x20+u20*u30)/a)
Ap = subs(A,{x1,x2,x3,u1,u2,u3},{x10,x20,x30,u10,u20,u30})
Bp = subs(B,{x1,x2,x3,u1,u2,u3},{x10,x20,x30,u10,u20,u30})
%% Modelo incertidumbres
a = 1
b = 1
c = 1
x30n = sqrt((exp(-u10))/c)
x20n = b*x30n - u10*u30
x10n = sqrt((x20n+u20*u30)/a)
a11 = -2*a*((b*(828390857088487/(2251799813685248*c))^(1/2) + 3)/a)^(1/2)
a33 = -2*c*(828390857088487/(2251799813685248*c))^(1/2)
Tol = 10
a11n = ureal('a11n',a11,'Percentage',[-Tol Tol])
a33n = ureal('a33n',a33,'Percentage',[-Tol Tol])
bn = ureal('bn',b,'Percentage',[-Tol Tol])
Ac = [a11n 1 0;
     0, -1, bn;
     0, 0, a33n]
BL = double(Bp)
CL = [2 1 0;
      0 2 4]
DL = [0 0 0;
      0 0 0]
sys_inc = ss(Ac,BL,CL,DL)
sys = sys_inc.NominalValue
AL = sys.a
%% Matriz controlabilidad
n = 3; % N�mero de estados
p = 3; % N�mero de actuadores
r = 2; % N�mero de salidas
Ahat = [AL, zeros(n,r);
        -CL, zeros(r,r)]
Bhat = [BL;
        -DL]
Mc = ctrb(Ahat,Bhat)
rank(Mc) % El rango debe ser igual a n+r
%% Dise�o Controlador polos reales
ts = 3;
s1 = -4/ts
delta = diag([s1, 2*s1, 4*s1, 10*s1, 10*s1]) % Matriz cuadrada de n+r
% Grand = 2*rand(p,n+r)-1;
Grand = [0.275418196144348,0.352244607727504,0.390280999103474,-0.551919938351563,-0.311075177397916;0.915387879683167,-0.421870856651047,-0.864014463059979,0.335665454027433,0.561039305462716;-0.518585929039680,0.343616330828430,-0.490419686805989,0.688784313054409,0.350664131493999];
X = lyap(Ahat, -delta, -Bhat*Grand);
det(X)
K = Grand*inv(X)
Kes = K(:,1:n)
Ki = -K(:,n+1:end)
%% Dise�o polos complejos
ts = 3;
Mp = 0.05
zita = abs(log(Mp))/sqrt(pi^2+(log(Mp))^2);
wn = 4/(zita*ts)
wd = wn*sqrt(1-zita^2)
s1 = -zita*wn + j*wd
delta = [real(s1) imag(s1) 0 0 0;  % Matriz cuadrada de n+r
        -imag(s1) real(s1) 0 0 0;
        0 0 1.5*real(s1) 0 0;
        0 0 0 2*real(s1) 0;
        0 0 0 0 10*real(s1)]
%Grand = 2*rand(p,n+r)-1;
Grand = [0.491092147403435,-0.631611804968947,-0.731754134342635,-0.857094374425911,-0.116555885871152;0.472534911193277,0.194422700675710,-0.574796933282314,-0.515026882126561,-0.973433599065495;0.123722850563275,-0.400126019820422,0.789883350881629,-0.892491215582572,0.794382701947144];
X = lyap(Ahat, -delta, -Bhat*Grand);
det(X)
K = Grand*inv(X)
Kes = K(:,1:n)
Ki = -K(:,n+1:end)
%% Control �ptimo
Q = diag([0.1 1 10 1 1])      % Matriz diagonal de tama�o n+r
R = diag([0.1 0.1 0.1])           % Matriz diagonal de tama�o p
[K,S,E] = lqr(Ahat,Bhat,Q,R)
[K1,S,E] = lqi(sys,Q,R)
Kes = K(:,1:n)
Ki = -K(:,n+1:end)
%% Modelo en lazo cerrado
AA = [AL - BL*Kes, BL*Ki;
     -CL + DL*Kes , -DL*Ki]
eig(AA)
BB = [zeros(n,r);
      eye(r)]
CC = [CL - DL*Kes, DL*Ki]
DD = zeros(r,r);
sys_new = ss(AA,BB,CC,DD)
figure(1)
step(sys_new)
grid

% Acci�n de control
CC1 = [-Kes, Ki];
DD1 = zeros(p,r);
sys_u = ss(AA,BB,CC1,DD1)
figure(2)
step(sys_u)
grid
